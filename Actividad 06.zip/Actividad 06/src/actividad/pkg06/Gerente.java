/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg06;

/**
 *
 * @author lucib
 */
public class Gerente extends Supervisor {
    private final double acciones;
    
    public Gerente (String nombre, double salario, double bono, double acciones) {
        super (nombre, salario, bono);
        this.acciones = acciones;
    }

    @Override public double calcularSalario () {
        return 
        super.calcularSalario () + this.acciones;        
    }
}
