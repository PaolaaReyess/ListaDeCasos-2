/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg06;

/**
 *
 * @author lucib
 */
abstract class Empleado {
    protected String nombre;
    protected double salario;

    public Empleado(String nombre, double salario) {
        this.nombre = nombre;
        this.salario = salario;
    }
    
    public abstract double calcularSalario ();
        public void despedir () {
        System.out.println("El empleado: " + this.nombre + "ha sido despedido");
    }
    public void promocionar () {
        System.out.println("El empleado " + this.nombre + "ha sido promovido. ");
    }
    
    public void jubilar() {
        System.out.println("El empleado " + this.nombre + "ha sido jubilado. ");
    } 
}
