/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg06;

/**
 *
 * @author lucib
 */
public class Supervisor extends Empleado {
    private final double bono;
    
    public Supervisor (String nombre, double salario, double bono) {
        super (nombre, salario);
        this.bono = bono;
    }

    @Override
    public double calcularSalario() {
        return this.salario + this.bono;
    }
}
