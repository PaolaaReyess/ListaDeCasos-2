/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad.pkg01;

/**
 *
 * @author lucib
 */
public class Hora {
 
  private int horas;
  private int minutos;
  private int segundos;

  public Hora() {
    this.horas = 0;
    this.minutos = 0;
    this.segundos = 0;
  }

  public Hora(int h, int m, int s) {
    this.horas = h;
    this.minutos = m;
    this.segundos = s;
  }

  public void mostrar() {
    System.out.printf("%02d:%02d:%02d\n", this.horas, this.minutos, this.segundos);
  }

  public Hora sumar(Hora h1, Hora h2) {
    
    Hora h3 = new Hora();
    h3.segundos = h1.segundos + h2.segundos;
    if (h3.segundos >= 60) {
      h3.minutos++;
      h3.segundos -= 60;
    }
    
    h3.minutos += h1.minutos + h2.minutos;
    if (h3.minutos >= 60) {
      h3.horas++;
      h3.minutos -= 60;
    }
    h3.horas += h1.horas + h2.horas;
    if (h3.horas >= 24) {
      h3.horas -= 24;
    }
    return h3;
  }
}