/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg01;

/**
 *
 * @author lucib
 */
public class Main {
  public static void main(String[] args) {
    Hora h1 = new Hora(10, 15, 30);
    Hora h2 = new Hora(12, 45, 50);
    Hora h3 = new Hora();
    h3 = h3.sumar(h1, h2);
    h3.mostrar();
  }
}
