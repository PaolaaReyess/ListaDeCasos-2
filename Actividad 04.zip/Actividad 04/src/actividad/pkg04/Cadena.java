/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg04;

/**
 *
 * @author lucib
 */
public class Cadena {
    private final int longuitud;
    private final String cadena;

    public Cadena(int longuitud, String cadena) {
        this.longuitud = cadena.length();
        this.cadena = cadena;
    }

    public int getLonguitud() {
        return longuitud;
    }

    public String getCadena() {
        return cadena;
    }
    
    public void visualizar (){
        System.out.println("Cadena: " + this.cadena);
        System.out.println("Longuitud: " + this.longuitud);
    }
    
    public char carcater (int i) {
        if (i >= this.longuitud) {
            return (char) -1;
        } else {
            return this.cadena.charAt (i);
        }
    }
    }
