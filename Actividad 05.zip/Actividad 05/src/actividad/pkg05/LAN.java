/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg05;

/**
 *
 * @author lucib
 */
import java.util.ArrayList;
import java.util.List;

abstract class LAN {
    protected List<String> nodos;
    protected String soporteTransmision;
    protected String controlAcceso;
    protected String formatoMarcoDatos;
    protected String estandares;
    protected int velocidadTransmision;

    public LAN() {
        this.nodos = new ArrayList<>();
    }

    public void agregarNodo(String nodo) {
        this.nodos.add(nodo);
    }

    public void quitarNodo(String nodo) {
        this.nodos.remove(nodo);
    }

    public void enumerarNodos() {
        System.out.println("Nodos actuales de la red LAN: " + this.nodos);
    }

    public abstract void configurarRed();

    public abstract void enviarPaquete(String nodoOrigen, String nodoDestino);

    public abstract void difundirPaquete(String nodoOrigen);
}

