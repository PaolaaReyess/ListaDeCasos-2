/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad.pkg05;

/**
 *
 * @author lucib
 */
class Bus extends LAN {
    @Override
    public void configurarRed() {
        System.out.println("Configurando red con topología de bus...");
    }

    @Override
    public void enviarPaquete(String nodoOrigen, String nodoDestino) {
        System.out.println("Enviando paquete desde " + nodoOrigen + " a " + nodoDestino + " en red de bus...");
    }

    @Override
    public void difundirPaquete(String nodoOrigen) {
        System.out.println("Difundiendo paquete desde " + nodoOrigen + " a todos los nodos en red de bus...");
    }
}