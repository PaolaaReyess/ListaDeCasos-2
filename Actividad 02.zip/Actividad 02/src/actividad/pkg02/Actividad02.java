/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad.pkg02;

/**
 *
 * @author lucib
 */
public class Actividad02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        Empleado[] empleados = new Empleado[50];

        for (int i = 0; i < empleados.length; i++) {
            empleados[i] = new Empleado();
            empleados[i].leerDatos();
        }

        for (Empleado empleado : empleados) {
            empleado.verDatos();
        }
    }
}
    